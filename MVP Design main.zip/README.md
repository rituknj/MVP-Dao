Betswamp is a decentralized peer-to-peer iGaming platform built on Binance smart chain. The platform completely takes out the traditional odds and booking system found in conventional centralized platforms and provide gamers the flexibility to create betting events on any category and terms of choice that other players can wager on, hence offering no limitation on the types of event created nor the size of the reward pool attached to the event.

*** Betswamp MVP milestones (Web3) ***
- connect and disconnect wallet
- creation of events (only admin)
- place a bet
- claim bet event winnings
- reclaim bet event winnings (i.e. if betting event is cancelled or something else occurs).
- retrieve user bet history
- lock BETS token to earn validation points
- show validation points
- unlock BETS token
- show active events
- show validated events
- show matched and unmatched events
- show events for validation and validate event
- add admin (only admin)
- remove admin (only admin)
- show list of admins
- add sub-category (only admin)
- show list of sub-category of a category
- pause platform (onlyOwner)

Here's a URL to the platform UI to get a clear view of what the platform looks like: https://dreamy-kilby-5b7252.netlify.app/app
