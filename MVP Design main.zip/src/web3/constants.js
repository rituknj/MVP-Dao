
export const CONNECTOR_ID = 'BET_APP_CONNECT_ID';

export const ConnectorID = {
    MetaMask: 'META_MASK'
};